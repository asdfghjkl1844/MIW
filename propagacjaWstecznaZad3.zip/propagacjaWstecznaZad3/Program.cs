﻿using System;
using System.IO;
using System.Collections.Generic;

class Neuron
{
    public double[] Wagi;
    public double Wyjscie;
    public double Delta;

    private static Random rand = new Random();
    private double beta = 1.0;

    public Neuron(int liczbaWejsc)
    {
        Wagi = new double[liczbaWejsc + 1];
        for (int i = 0; i < Wagi.Length; i++)
            Wagi[i] = rand.NextDouble() * 2 - 1;
    }

    public double Aktywuj(double[] Wejscia)
    {
        double suma = Wagi[Wagi.Length - 1];
        for (int i = 0; i < Wejscia.Length; i++)
            suma += Wagi[i] * Wejscia[i];

        Wyjscie = Sigmoida(suma);
        return Wyjscie;
    }

    private double Sigmoida(double x)
    {
        return 1.0 / (1.0 + Math.Exp(-beta * x));
    }

    public double PochodnaSigmoidy()
    {
        return Wyjscie * (1 - Wyjscie);
    }
}

class Warstwa
{
    public Neuron[] Neurony;

    public Warstwa(int liczbaNeuronow, int liczbaWejsc)
    {
        Neurony = new Neuron[liczbaNeuronow];
        for (int i = 0; i < liczbaNeuronow; i++)
            Neurony[i] = new Neuron(liczbaWejsc);
    }

    public double[] PropagacjaWPrzod(double[] Wejscia)
    {
        double[] Wyjscia = new double[Neurony.Length];
        for (int i = 0; i < Neurony.Length; i++)
            Wyjscia[i] = Neurony[i].Aktywuj(Wejscia);
        return Wyjscia;
    }
}

class SiecNeuronowa
{
    private Warstwa Warstwa1, Warstwa2, Warstwa3;
    private double WspolczynnikUczenia = 0.3;
    private int Epoki = 150000;

    public SiecNeuronowa()
    {
        Warstwa1 = new Warstwa(3, 3);
        Warstwa2 = new Warstwa(2, 3);
        Warstwa3 = new Warstwa(2, 2);
    }

    public double[] PropagacjaWPrzod(double[] Wejscia)
    {
        var W1 = Warstwa1.PropagacjaWPrzod(Wejscia);
        var W2 = Warstwa2.PropagacjaWPrzod(W1);
        return Warstwa3.PropagacjaWPrzod(W2);
    }

    public void PropagacjaWTyl(double[][] DaneWejsciowe, double[][] OczekiwaneWyniki)
    {
        for (int epoka = 0; epoka < Epoki; epoka++)
        {
            double BladCalkowity = 0;
            for (int i = 0; i < DaneWejsciowe.Length; i++)
            {
                var W1 = Warstwa1.PropagacjaWPrzod(DaneWejsciowe[i]);
                var W2 = Warstwa2.PropagacjaWPrzod(W1);
                var Wyjscie = Warstwa3.PropagacjaWPrzod(W2);

                double[] Blad = new double[Wyjscie.Length];
                for (int j = 0; j < Wyjscie.Length; j++)
                {
                    Blad[j] = OczekiwaneWyniki[i][j] - Wyjscie[j];
                    Warstwa3.Neurony[j].Delta = Blad[j] * Warstwa3.Neurony[j].PochodnaSigmoidy();
                    BladCalkowity += Math.Abs(Blad[j]);
                }

                for (int j = 0; j < Warstwa2.Neurony.Length; j++)
                {
                    double suma = 0;
                    for (int k = 0; k < Warstwa3.Neurony.Length; k++)
                        suma += Warstwa3.Neurony[k].Delta * Warstwa3.Neurony[k].Wagi[j];
                    Warstwa2.Neurony[j].Delta = suma * Warstwa2.Neurony[j].PochodnaSigmoidy();
                }

                for (int j = 0; j < Warstwa1.Neurony.Length; j++)
                {
                    double suma = 0;
                    for (int k = 0; k < Warstwa2.Neurony.Length; k++)
                        suma += Warstwa2.Neurony[k].Delta * Warstwa2.Neurony[k].Wagi[j];
                    Warstwa1.Neurony[j].Delta = suma * Warstwa1.Neurony[j].PochodnaSigmoidy();
                }

                AktualizujWagi(Warstwa3, W2);
                AktualizujWagi(Warstwa2, W1);
                AktualizujWagi(Warstwa1, DaneWejsciowe[i]);
            }

            if (epoka % 15000 == 0)
                Console.WriteLine($"Epoka {epoka}, Blad: {BladCalkowity}");
        }
    }

    private void AktualizujWagi(Warstwa warstwa, double[] wejscia)
    {
        foreach (var neuron in warstwa.Neurony)
        {
            for (int i = 0; i < wejscia.Length; i++)
                neuron.Wagi[i] += WspolczynnikUczenia * neuron.Delta * wejscia[i];
            neuron.Wagi[wejscia.Length] += WspolczynnikUczenia * neuron.Delta;
        }
    }

    static void Main()
    {

        string danePlik = "sumatorek.txt";
        string nazwyPlik = "sumatorek-names.txt";

        (double[][] DaneWejsciowe, double[][] OczekiwaneWyniki) = WczytajDane(danePlik);
        (string[] nazwyWe, string[] nazwyWy) = WczytajNazwy(nazwyPlik);

        var siec = new SiecNeuronowa();
        siec.PropagacjaWTyl(DaneWejsciowe, OczekiwaneWyniki);

        Console.WriteLine("\nWyniki:");
        for (int i = 0; i < DaneWejsciowe.Length; i++)
        {
            var wejscie = DaneWejsciowe[i];
            var wyjscie = siec.PropagacjaWPrzod(wejscie);

            string wejscieOpis = string.Join(", ", wejscie.Select((v, j) => $"{nazwyWe[j]}={v}"));
            string wyjscieOpis = string.Join(", ", wyjscie.Select((v, j) => $"{nazwyWy[j]}={Math.Round(v, 2)}"));

            Console.WriteLine($"[{wejscieOpis}] -> [{wyjscieOpis}]");
        }
    }
    static (double[][], double[][]) WczytajDane(string sciezka)
    {
        var wejscia = new List<double[]>();
        var wyjscia = new List<double[]>();

        foreach (var linia in File.ReadAllLines(sciezka))
        {
            var wartosci = linia.Split(' ', StringSplitOptions.RemoveEmptyEntries)
                              .Select(double.Parse).ToArray();

            var input = wartosci.Take(3).ToArray();
            var output = wartosci.Skip(3).ToArray();

            wejscia.Add(input);
            wyjscia.Add(output);
        }

        return (wejscia.ToArray(), wyjscia.ToArray());
    }

static (string[], string[]) WczytajNazwy(string sciezka)
{
    var linie = File.ReadAllLines(sciezka);
    var nazwyWe = new List<string>();
    var nazwyWy = new List<string>();

    foreach (var linia in linie)
    {
        var podzielone = linia.Split('\t');
        if (podzielone.Length >= 2)
        {
            string nazwa = podzielone[0];
            if (nazwa.StartsWith("we_"))
                nazwyWe.Add(nazwa);
            else if (nazwa.StartsWith("wy_"))
                nazwyWy.Add(nazwa);
        }
    }

    return (nazwyWe.ToArray(), nazwyWy.ToArray());
}

}
