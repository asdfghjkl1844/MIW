﻿namespace SieciNeuronoweGUI
{
    public class Warstwa
    {
        public Neuron[] Neurony;
        public Warstwa(int liczbaNeuronow, int liczbaWejsc)
        {
            Neurony = new Neuron[liczbaNeuronow];
            for (int i = 0; i < liczbaNeuronow; i++)
                Neurony[i] = new Neuron(liczbaWejsc);
        }

        public double[] PropagacjaWPrzod(double[] Wejscia)
        {
            double[] Wyjscia = new double[Neurony.Length];
            for (int i = 0; i < Neurony.Length; i++)
                Wyjscia[i] = Neurony[i].Aktywuj(Wejscia);
            return Wyjscia;
        }
    }
}
