﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SieciNeuronoweGUI
{
    public partial class Form1 : Form
    {
        private ISiecNeuronowa siec;

        public Form1()
        {
            InitializeComponent();
            cmbTypSieci.Items.AddRange(new string[] { "XOR", "XOR-NOR", "Sumatorek" });
            cmbTypSieci.SelectedIndex = 0;
        }

        private void btnTrenuj_Click(object sender, EventArgs e)
        {
            switch (cmbTypSieci.SelectedItem.ToString())
            {
                case "XOR":
                    siec = new XorNetwork();
                    siec.Trenuj("xor.txt", "xor-names.txt");
                    break;
                case "XOR-NOR":
                    siec = new XorNorNetwork();
                    siec.Trenuj("xor_nor.txt", "xor_nor-names.txt");
                    break;
                case "Sumatorek":
                    siec = new SumatorekNetwork();
                    siec.Trenuj("sumatorek.txt", "sumatorek-names.txt");
                    break;
            }
            txtWyniki.Text = "Trening zakończony, kliknij 'Pokaż wyniki'";
        }

        private void btnWyniki_Click(object sender, EventArgs e)
        {
            if (siec == null)
            {
                MessageBox.Show("Najpierw wytrenuj wybraną sieć!");
                return;
            }
            txtWyniki.Text = siec.WynikiTekst();
        }

    }
}
