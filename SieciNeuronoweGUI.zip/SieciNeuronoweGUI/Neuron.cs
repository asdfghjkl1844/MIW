﻿using System;

namespace SieciNeuronoweGUI
{
    public class Neuron
    {
        public double[] Wagi;
        public double Wyjscie;
        public double Delta;
        private static Random rand = new Random();
        private double beta = 1.0;

        public Neuron(int liczbaWejsc)
        {
            Wagi = new double[liczbaWejsc + 1];
            for (int i = 0; i < Wagi.Length; i++)
                Wagi[i] = rand.NextDouble() * 2 - 1;
        }

        public double Aktywuj(double[] Wejscia)
        {
            double suma = Wagi[Wagi.Length - 1];
            for (int i = 0; i < Wejscia.Length; i++)
                suma += Wagi[i] * Wejscia[i];
            Wyjscie = Sigmoida(suma);
            return Wyjscie;
        }

        private double Sigmoida(double x)
        {
            return 1.0 / (1.0 + Math.Exp(-beta * x));
        }

        public double PochodnaSigmoidy()
        {
            return Wyjscie * (1 - Wyjscie);
        }
    }
}
