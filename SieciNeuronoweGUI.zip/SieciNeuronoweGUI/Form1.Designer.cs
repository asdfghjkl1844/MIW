﻿namespace SieciNeuronoweGUI
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbTypSieci = new System.Windows.Forms.ComboBox();
            this.btnTrenuj = new System.Windows.Forms.Button();
            this.btnWyniki = new System.Windows.Forms.Button();
            this.txtWyniki = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cmbTypSieci
            // 
            this.cmbTypSieci.FormattingEnabled = true;
            this.cmbTypSieci.Location = new System.Drawing.Point(312, 62);
            this.cmbTypSieci.Name = "cmbTypSieci";
            this.cmbTypSieci.Size = new System.Drawing.Size(121, 24);
            this.cmbTypSieci.TabIndex = 0;
            this.cmbTypSieci.Text = "Wybierz sieć";
            // 
            // btnTrenuj
            // 
            this.btnTrenuj.Location = new System.Drawing.Point(190, 142);
            this.btnTrenuj.Name = "btnTrenuj";
            this.btnTrenuj.Size = new System.Drawing.Size(75, 23);
            this.btnTrenuj.TabIndex = 1;
            this.btnTrenuj.Text = "Trenuj";
            this.btnTrenuj.UseVisualStyleBackColor = true;
            this.btnTrenuj.Click += new System.EventHandler(this.btnTrenuj_Click);
            // 
            // btnWyniki
            // 
            this.btnWyniki.Location = new System.Drawing.Point(480, 142);
            this.btnWyniki.Name = "btnWyniki";
            this.btnWyniki.Size = new System.Drawing.Size(142, 23);
            this.btnWyniki.TabIndex = 2;
            this.btnWyniki.Text = "Pokaż wyniki";
            this.btnWyniki.UseVisualStyleBackColor = true;
            this.btnWyniki.Click += new System.EventHandler(this.btnWyniki_Click);
            // 
            // txtWyniki
            // 
            this.txtWyniki.Location = new System.Drawing.Point(214, 199);
            this.txtWyniki.Multiline = true;
            this.txtWyniki.Name = "txtWyniki";
            this.txtWyniki.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtWyniki.Size = new System.Drawing.Size(360, 134);
            this.txtWyniki.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtWyniki);
            this.Controls.Add(this.btnWyniki);
            this.Controls.Add(this.btnTrenuj);
            this.Controls.Add(this.cmbTypSieci);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbTypSieci;
        private System.Windows.Forms.Button btnTrenuj;
        private System.Windows.Forms.Button btnWyniki;
        private System.Windows.Forms.TextBox txtWyniki;
    }
}

