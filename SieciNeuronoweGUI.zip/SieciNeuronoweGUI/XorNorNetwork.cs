﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SieciNeuronoweGUI
{
    public class XorNorNetwork : ISiecNeuronowa
    {
        private Warstwa Warstwa1, Warstwa2, Warstwa3;
        private double WspolczynnikUczenia = 0.3;
        private int Epoki = 100000;
        private double[][] DaneWejsciowe, OczekiwaneWyniki;
        private string[] NazwyWe, NazwyWy;

        public void Trenuj(string plikDanych, string plikNazw)
        {
            (DaneWejsciowe, OczekiwaneWyniki) = WczytajDane(plikDanych);
            (NazwyWe, NazwyWy) = WczytajNazwy(plikNazw);

            Warstwa1 = new Warstwa(2, 2);
            Warstwa2 = new Warstwa(2, 2);
            Warstwa3 = new Warstwa(2, 2);

            for (int epoka = 0; epoka < Epoki; epoka++)
            {
                for (int i = 0; i < DaneWejsciowe.Length; i++)
                {
                    var W1 = Warstwa1.PropagacjaWPrzod(DaneWejsciowe[i]);
                    var W2 = Warstwa2.PropagacjaWPrzod(W1);
                    var Wyjscie = Warstwa3.PropagacjaWPrzod(W2);

                    double[] Blad = new double[OczekiwaneWyniki[i].Length];
                    for (int j = 0; j < Blad.Length; j++)
                    {
                        Blad[j] = OczekiwaneWyniki[i][j] - Wyjscie[j];
                        Warstwa3.Neurony[j].Delta = Blad[j] * Warstwa3.Neurony[j].PochodnaSigmoidy();
                    }

                    for (int j = 0; j < Warstwa2.Neurony.Length; j++)
                    {
                        double suma = 0;
                        for (int k = 0; k < Warstwa3.Neurony.Length; k++)
                            suma += Warstwa3.Neurony[k].Delta * Warstwa3.Neurony[k].Wagi[j];
                        Warstwa2.Neurony[j].Delta = suma * Warstwa2.Neurony[j].PochodnaSigmoidy();
                    }

                    for (int j = 0; j < Warstwa1.Neurony.Length; j++)
                    {
                        double suma = 0;
                        for (int k = 0; k < Warstwa2.Neurony.Length; k++)
                            suma += Warstwa2.Neurony[k].Delta * Warstwa2.Neurony[k].Wagi[j];
                        Warstwa1.Neurony[j].Delta = suma * Warstwa1.Neurony[j].PochodnaSigmoidy();
                    }

                    AktualizujWagi(Warstwa3, W2);
                    AktualizujWagi(Warstwa2, W1);
                    AktualizujWagi(Warstwa1, DaneWejsciowe[i]);
                }
            }
        }

        private void AktualizujWagi(Warstwa warstwa, double[] wejscia)
        {
            foreach (var neuron in warstwa.Neurony)
            {
                for (int i = 0; i < wejscia.Length; i++)
                    neuron.Wagi[i] += WspolczynnikUczenia * neuron.Delta * wejscia[i];
                neuron.Wagi[wejscia.Length] += WspolczynnikUczenia * neuron.Delta;
            }
        }

        public string WynikiTekst()
        {
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < DaneWejsciowe.Length; i++)
            {
                var wejscie = DaneWejsciowe[i];
                var wyjscie = PropagacjaWPrzod(wejscie);

                string wejscieOpis = string.Join(", ", wejscie.Select((v, j) => $"{NazwyWe[j]}={v}"));
                string wyjscieOpis = string.Join(", ", wyjscie.Select((v, j) => $"{NazwyWy[j]}={Math.Round(v, 2)}"));
                sb.AppendLine($"[{wejscieOpis}] → [{wyjscieOpis}]");
            }
            return sb.ToString();
        }

        public double[] PropagacjaWPrzod(double[] wejscia)
        {
            var W1 = Warstwa1.PropagacjaWPrzod(wejscia);
            var W2 = Warstwa2.PropagacjaWPrzod(W1);
            return Warstwa3.PropagacjaWPrzod(W2);
        }

        private (double[][], double[][]) WczytajDane(string sciezka)
        {
            var wejscia = new List<double[]>();
            var wyjscia = new List<double[]>();
            foreach (var linia in File.ReadAllLines(sciezka))
            {
                var wartosci = linia.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(double.Parse).ToArray();
                wejscia.Add(wartosci.Take(2).ToArray());
                wyjscia.Add(wartosci.Skip(2).ToArray());
            }
            return (wejscia.ToArray(), wyjscia.ToArray());
        }
        private (string[], string[]) WczytajNazwy(string sciezka)
        {
            var linie = File.ReadAllLines(sciezka);
            var nazwyWe = new List<string>();
            var nazwyWy = new List<string>();
            foreach (var linia in linie)
            {
                var podzielone = linia.Split('\t');
                if (podzielone.Length >= 2)
                {
                    string nazwa = podzielone[0];
                    if (nazwa.StartsWith("we_"))
                        nazwyWe.Add(nazwa);
                    else if (nazwa.StartsWith("wy_"))
                        nazwyWy.Add(nazwa);
                }
            }
            return (nazwyWe.ToArray(), nazwyWy.ToArray());
        }
    }
}
