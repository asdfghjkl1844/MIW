﻿namespace SieciNeuronoweGUI
{
    public interface ISiecNeuronowa
    {
        void Trenuj(string plikDanych, string plikNazw);
        string WynikiTekst();
    }
}
