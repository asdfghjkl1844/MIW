﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace SieciNeuronoweGUI
{
    public class XorNetwork : ISiecNeuronowa
    {
        private Warstwa WarstwaUkryta, WarstwaWyjsciowa;
        private double WspolczynnikUczenia = 0.3;
        private int Epoki = 50000;
        private double[][] DaneWejsciowe, OczekiwaneWyniki;
        private string[] NazwyWe, NazwyWy;

        public void Trenuj(string plikDanych, string plikNazw)
        {
            (DaneWejsciowe, OczekiwaneWyniki) = WczytajDane(plikDanych);
            (NazwyWe, NazwyWy) = WczytajNazwy(plikNazw);

            WarstwaUkryta = new Warstwa(2, 2);
            WarstwaWyjsciowa = new Warstwa(1, 2);

            for (int epoka = 0; epoka < Epoki; epoka++)
            {
                for (int i = 0; i < DaneWejsciowe.Length; i++)
                {
                    var WyjsciaUkryte = WarstwaUkryta.PropagacjaWPrzod(DaneWejsciowe[i]);
                    var WynikiKoncowe = WarstwaWyjsciowa.PropagacjaWPrzod(WyjsciaUkryte);

                    double Blad = OczekiwaneWyniki[i][0] - WynikiKoncowe[0];
                    WarstwaWyjsciowa.Neurony[0].Delta = Blad * WarstwaWyjsciowa.Neurony[0].PochodnaSigmoidy();

                    for (int j = 0; j < WarstwaUkryta.Neurony.Length; j++)
                    {
                        double waga = WarstwaWyjsciowa.Neurony[0].Wagi[j];
                        WarstwaUkryta.Neurony[j].Delta = WarstwaWyjsciowa.Neurony[0].Delta * waga * WarstwaUkryta.Neurony[j].PochodnaSigmoidy();
                    }

                    AktualizujWagi(WarstwaWyjsciowa, WyjsciaUkryte);
                    AktualizujWagi(WarstwaUkryta, DaneWejsciowe[i]);
                }
            }
        }

        private void AktualizujWagi(Warstwa warstwa, double[] wejscia)
        {
            foreach (var neuron in warstwa.Neurony)
            {
                for (int i = 0; i < wejscia.Length; i++)
                    neuron.Wagi[i] += WspolczynnikUczenia * neuron.Delta * wejscia[i];
                neuron.Wagi[wejscia.Length] += WspolczynnikUczenia * neuron.Delta;
            }
        }

        public string WynikiTekst()
        {
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < DaneWejsciowe.Length; i++)
            {
                var wejscie = DaneWejsciowe[i];
                var wyjscie = PropagacjaWPrzod(wejscie);

                string wejscieOpis = string.Join(", ", wejscie.Select((v, j) => $"{NazwyWe[j]}={v}"));
                string wyjscieOpis = string.Join(", ", wyjscie.Select((v, j) => $"{NazwyWy[j]}={Math.Round(v, 2)}"));
                sb.AppendLine($"[{wejscieOpis}] → [{wyjscieOpis}]");
            }
            return sb.ToString();
        }

        public double[] PropagacjaWPrzod(double[] Wejscia)
        {
            var WyjsciaUkryte = WarstwaUkryta.PropagacjaWPrzod(Wejscia);
            return WarstwaWyjsciowa.PropagacjaWPrzod(WyjsciaUkryte);
        }

        private (double[][], double[][]) WczytajDane(string sciezka)
        {
            var wejscia = new List<double[]>();
            var wyjscia = new List<double[]>();
            foreach (var linia in File.ReadAllLines(sciezka))
            {
                var wartosci = linia.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Select(double.Parse).ToArray();
                wejscia.Add(wartosci.Take(2).ToArray());
                wyjscia.Add(wartosci.Skip(2).ToArray());
            }
            return (wejscia.ToArray(), wyjscia.ToArray());
        }
        private (string[], string[]) WczytajNazwy(string sciezka)
        {
            var linie = File.ReadAllLines(sciezka);
            var nazwyWe = new List<string>();
            var nazwyWy = new List<string>();
            foreach (var linia in linie)
            {
                var podzielone = linia.Split('\t');
                if (podzielone.Length >= 2)
                {
                    string nazwa = podzielone[0];
                    if (nazwa.StartsWith("we_"))
                        nazwyWe.Add(nazwa);
                    else if (nazwa.StartsWith("wy_"))
                        nazwyWy.Add(nazwa);
                }
            }
            return (nazwyWe.ToArray(), nazwyWy.ToArray());
        }
    }
}
