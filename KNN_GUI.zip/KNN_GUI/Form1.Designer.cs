﻿namespace knn
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnPlik = new Button();
            lblPlik = new Label();
            txtK = new TextBox();
            cmbMetryka = new ComboBox();
            btnOblicz = new Button();
            txtWynik = new Label();
            txtSzczegoly = new TextBox();
            SuspendLayout();
            // 
            // btnPlik
            // 
            btnPlik.Location = new Point(39, 131);
            btnPlik.Name = "btnPlik";
            btnPlik.Size = new Size(129, 29);
            btnPlik.TabIndex = 0;
            btnPlik.Text = "Wybierz plik";
            btnPlik.UseVisualStyleBackColor = true;
            btnPlik.Click += btnPlik_Click;
            // 
            // lblPlik
            // 
            lblPlik.AutoSize = true;
            lblPlik.Location = new Point(42, 187);
            lblPlik.Name = "lblPlik";
            lblPlik.Size = new Size(32, 20);
            lblPlik.TabIndex = 1;
            lblPlik.Text = "Plik";
            // 
            // txtK
            // 
            txtK.Location = new Point(204, 58);
            txtK.Name = "txtK";
            txtK.Size = new Size(151, 27);
            txtK.TabIndex = 2;
            txtK.Text = "k";
            // 
            // cmbMetryka
            // 
            cmbMetryka.FormattingEnabled = true;
            cmbMetryka.Location = new Point(42, 57);
            cmbMetryka.Name = "cmbMetryka";
            cmbMetryka.Size = new Size(151, 28);
            cmbMetryka.TabIndex = 3;
            cmbMetryka.Text = "Metryka";
            // 
            // btnOblicz
            // 
            btnOblicz.Location = new Point(43, 233);
            btnOblicz.Name = "btnOblicz";
            btnOblicz.Size = new Size(94, 29);
            btnOblicz.TabIndex = 4;
            btnOblicz.Text = "Oblicz";
            btnOblicz.UseVisualStyleBackColor = true;
            btnOblicz.Click += btnOblicz_Click;
            // 
            // txtWynik
            // 
            txtWynik.AutoSize = true;
            txtWynik.Location = new Point(45, 281);
            txtWynik.Name = "txtWynik";
            txtWynik.Size = new Size(49, 20);
            txtWynik.TabIndex = 5;
            txtWynik.Text = "Wynik";
            // 
            // txtSzczegoly
            // 
            txtSzczegoly.Location = new Point(373, 57);
            txtSzczegoly.Multiline = true;
            txtSzczegoly.Name = "txtSzczegoly";
            txtSzczegoly.ReadOnly = true;
            txtSzczegoly.ScrollBars = ScrollBars.Vertical;
            txtSzczegoly.Size = new Size(410, 108);
            txtSzczegoly.TabIndex = 6;
            txtSzczegoly.Text = "Szczegóły";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtSzczegoly);
            Controls.Add(txtWynik);
            Controls.Add(btnOblicz);
            Controls.Add(cmbMetryka);
            Controls.Add(txtK);
            Controls.Add(lblPlik);
            Controls.Add(btnPlik);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnPlik;
        private Label lblPlik;
        private TextBox txtK;
        private ComboBox cmbMetryka;
        private Button btnOblicz;
        private Label txtWynik;
        private TextBox txtSzczegoly;
    }
}
