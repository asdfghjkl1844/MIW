﻿public static class Metryki
{
    public static double Euklidesowa(double[] A, double[] B)
    {
        double wynik = 0;
        for (int i = 0; i < A.Length; i++)
            wynik += (A[i] - B[i]) * (A[i] - B[i]);
        return Math.Sqrt(wynik);
    }

    public static double Manhattan(double[] A, double[] B)
    {
        double wynik = 0;
        for (int i = 0; i < A.Length; i++)
            wynik += Math.Abs(A[i] - B[i]);
        return wynik;
    }

    public static double Czebyszewa(double[] A, double[] B)
    {
        double max = 0;
        for (int i = 0; i < A.Length; i++)
        {
            double diff = Math.Abs(A[i] - B[i]);
            if (diff > max)
                max = diff;
        }
        return max;
    }
}
