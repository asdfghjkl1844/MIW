using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Globalization;

namespace knn
{
    public partial class Form1 : Form
    {
        string sciezkaPliku = "";
        List<(double[], int)> dane = null;

        public Form1()
        {
            InitializeComponent();
            cmbMetryka.Items.AddRange(new string[] { "Euklidesowa", "Manhattan" });
            cmbMetryka.SelectedIndex = 0;
            txtK.Text = "3";
        }

        delegate double Metryka(double[] A, double[] B);

        static double Euklidesowa(double[] A, double[] B)
        {
            double wynik = 0;
            for (int i = 0; i < A.Length; i++)
                wynik += (A[i] - B[i]) * (A[i] - B[i]);
            return Math.Sqrt(wynik);
        }

        static double Manhattan(double[] A, double[] B)
        {
            double wynik = 0;
            for (int i = 0; i < A.Length; i++)
                wynik += Math.Abs(A[i] - B[i]);
            return wynik;
        }

        static List<(double[], int)> WczytajDane(string sciezka)
        {
            var dane = new List<(double[], int)>();
            foreach (var linia in File.ReadAllLines(sciezka))
            {
                if (string.IsNullOrWhiteSpace(linia)) continue;
                var wartosci = linia.Split('\t');   // tabulatory
                double[] cechy = wartosci.Take(wartosci.Length - 1)
                                         .Select(x => double.Parse(x, CultureInfo.InvariantCulture))
                                         .ToArray();
                int klasa = int.Parse(wartosci.Last());
                dane.Add((cechy, klasa));
            }
            return dane;
        }

        static void Normalizuj(List<(double[], int)> dane)
        {
            int liczbaCech = dane[0].Item1.Length;
            for (int i = 0; i < liczbaCech; i++)
            {
                double min = dane.Min(x => x.Item1[i]);
                double max = dane.Max(x => x.Item1[i]);
                foreach (var d in dane)
                    d.Item1[i] = (d.Item1[i] - min) / (max - min);
            }
        }

        static int Klasyfikuj(List<(double[], int)> uczace, double[] testowa, int k, Metryka metryka)
        {
            var sasiedzi = uczace
                .Select(x => (metryka(x.Item1, testowa), x.Item2))
                .OrderBy(x => x.Item1)
                .Take(k)
                .GroupBy(x => x.Item2)
                .OrderByDescending(g => g.Count())
                .ToList();

            if (sasiedzi.Count > 1 && sasiedzi[0].Count() == sasiedzi[1].Count())
                return -1; // odmowa odpowiedzi
            return sasiedzi.First().Key;
        }

        private void btnPlik_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Pliki tekstowe (*.txt;*.csv)|*.txt;*.csv|Wszystkie pliki (*.*)|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                sciezkaPliku = dlg.FileName;
                lblPlik.Text = sciezkaPliku;
                try
                {
                    dane = WczytajDane(sciezkaPliku);
                    txtWynik.Text = $"Wczytano {dane.Count} pr�bek";
                }
                catch (Exception ex)
                {
                    txtWynik.Text = "B��d wczytywania pliku: " + ex.Message;
                }
            }
        }

        private void btnOblicz_Click(object sender, EventArgs e)
        {
            if (dane == null)
            {
                txtWynik.Text = "Najpierw wybierz plik z danymi!";
                return;
            }
            if (!int.TryParse(txtK.Text, out int k) || k < 1)
            {
                txtWynik.Text = "Nieprawid�owa warto�� k";
                return;
            }

            // Musisz wybra� metryk�
            Metryka metryka = cmbMetryka.SelectedIndex == 1 ? Manhattan : Euklidesowa;

            // Deep copy listy!
            var daneNorm = dane.Select(x => ((double[])x.Item1.Clone(), x.Item2)).ToList();
            Normalizuj(daneNorm);

            int poprawne = 0;
            int odmowa = 0;
            for (int i = 0; i < daneNorm.Count; i++)
            {
                var testowa = daneNorm[i];
                var uczace = daneNorm.Where((x, idx) => idx != i).ToList();
                int predykcja = Klasyfikuj(uczace, testowa.Item1, k, metryka);
                if (predykcja == testowa.Item2)
                    poprawne++;
                else if (predykcja == -1)
                    odmowa++;
            }
            double dokladnosc = (double)poprawne / daneNorm.Count * 100.0;
            txtWynik.Text = $"Dok�adno��: {dokladnosc:F2}%\r\nOdm�wiono odpowiedzi dla {odmowa} pr�bek";
        }
    }
}
